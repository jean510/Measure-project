## IE-0624 Laboratorio de MIcrocontroladores : Proyecto Final Arduinómetro
---
Este repositorio contiene el proyecto del curso IE-0624 Laboratorio de Microcontroladores de la Universidad de Costa Rica, impartido por el profesor Marco Villalta Fallas.
## Instrucciones de uso
---
- Para compilar el programa utilice la extención de vscode de platformIO
- El firmware se almacenaen el directorio .pio/build/uno/
 
## Instalación de dependencias
---
- Extención de PlatformIO de vscode
## Repositorio oficial
---
Puede consultar el repositorio del proyecto desde [aquí](http://git.eie.ucr.ac.cr/microlab/arduinometro.git).

## Autores
---
- [jlopezp](https://git.eie.ucr.ac.cr/jlopezp) José López Picado
- [jpseguraa](https://git.eie.ucr.ac.cr/jpseguraa) Jean Pierre Segura


## Licencia
- MIT
